import java.sql.Drivermanager;
import java.sql.Connection;
import java.sql.DriverManager;

public class Connect {
	public static Connection dbcon() {
		try {
			class.forName("oracle.jdbc.driver.OracleDriver");
			Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl\",\"system\",\"1234");
			return c;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String[] args) throws ClassNotFoundException {
		
		if (dbcon() != null) {
			System.out.println("Connect");
		}
	}
}
